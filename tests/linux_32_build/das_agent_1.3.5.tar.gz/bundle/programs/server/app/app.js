var require = meteorInstall({"lib":{"mSettings.coffee.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// lib/mSettings.coffee.js                                                                     //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                               //
                                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"initServer.coffee.js":["fibers/future","fibers","fs",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// server/initServer.coffee.js                                                                 //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var cl, fiber, fs, future;                                                                     // 1
                                                                                               //
cl = console.log;                                                                              // 1
                                                                                               //
future = require('fibers/future');                                                             // 2
                                                                                               //
fiber = require('fibers');                                                                     // 3
                                                                                               //
fs = require('fs');                                                                            // 4
                                                                                               //
Meteor.startup(function() {                                                                    // 5
  var checkDir, fut, path;                                                                     // 21
  this.mSettings = (function() {                                                               //
    var obj, ref, ref1;                                                                        // 22
    return obj = {                                                                             // 22
      DMS_URL: typeof process !== "undefined" && process !== null ? (ref = process.env) != null ? ref._mSettings_DMS_URL : void 0 : void 0,
      AGENT_URL: typeof process !== "undefined" && process !== null ? (ref1 = process.env) != null ? ref1._mSettings_AGENT_URL : void 0 : void 0,
      setting: null                                                                            //
    };                                                                                         //
  })();                                                                                        //
  cl(mSettings);                                                                               //
  while (!mSettings.setting) {                                                                 // 27
    fut = new future();                                                                        //
    HTTP.post(mSettings.DMS_URL + "/getAgentSetting", {                                        //
      data: {                                                                                  //
        AGENT_URL: mSettings.AGENT_URL                                                         //
      }                                                                                        //
    }, function(err, rslt) {                                                                   //
      if (err) {                                                                               //
        cl(err);                                                                               //
        return fut["return"](null);                                                            //
      } else {                                                                                 //
        cl(mSettings.setting = JSON.parse(rslt.content));                                      //
        return fut["return"](mSettings.setting);                                               //
      }                                                                                        //
    });                                                                                        //
    mSettings.setting = fut.wait();                                                            //
    if (!mSettings.setting) {                                                                  //
      Meteor._sleepForMs(10000);                                                               //
    }                                                                                          //
  }                                                                                            //
  path = mSettings.setting.소멸정보절대경로;                                                           //
  checkDir = function() {                                                                      //
    var files;                                                                                 // 45
    files = fs.readdirSync(path);                                                              //
    files = files.filter(function(file) {                                                      //
      if (file.substring(file.length - 3, file.length) === 'das') {                            //
        return true;                                                                           //
      } else {                                                                                 //
        return false;                                                                          //
      }                                                                                        //
    });                                                                                        //
    return files.forEach(function(file) {                                                      //
      var dasInfo, err, error, error1;                                                         // 49
      try {                                                                                    // 49
        dasInfo = fs.readFileSync(path + "/" + file, 'utf-8');                                 //
        return HTTP.post(mSettings.DMS_URL + "/insertDAS", {                                   //
          data: {                                                                              //
            dasInfo: dasInfo,                                                                  //
            AGENT_URL: mSettings.AGENT_URL                                                     //
          }                                                                                    //
        }, function(err, rslt) {                                                               //
          var error;                                                                           // 57
          if (err) {                                                                           //
            cl(err);                                                                           //
            try {                                                                              // 60
              return fs.access(path + "/err", fs.F_OK, function(err) {                         //
                var errno;                                                                     // 62
                if (((errno = err != null ? err.errno : void 0) != null) && errno === -2) {    //
                  fs.mkdirSync(path + "/err");                                                 //
                }                                                                              //
                return fs.rename(path + "/" + file, path + "/err/" + file);                    //
              });                                                                              //
            } catch (error) {                                                                  //
              err = error;                                                                     //
              return cl(err);                                                                  //
            }                                                                                  //
          } else {                                                                             //
            return fs.unlinkSync(path + "/" + file);                                           //
          }                                                                                    //
        });                                                                                    //
      } catch (error) {                                                                        //
        err = error;                                                                           //
        if (err) {                                                                             //
          cl(err);                                                                             //
          try {                                                                                // 73
            return fs.access(path + "/err", fs.F_OK, function(err) {                           //
              var errno;                                                                       // 75
              if (((errno = err != null ? err.errno : void 0) != null) && errno === -2) {      //
                fs.mkdirSync(path + "/err");                                                   //
              }                                                                                //
              return fs.rename(path + "/" + file, path + "/err/" + file);                      //
            });                                                                                //
          } catch (error1) {                                                                   //
            err = error1;                                                                      //
            return cl(err);                                                                    //
          }                                                                                    //
        }                                                                                      //
      }                                                                                        //
    });                                                                                        //
  };                                                                                           //
  checkDir();                                                                                  //
  return setInterval(function() {                                                              //
    return fiber(function() {                                                                  //
      return checkDir();                                                                       //
    }).run();                                                                                  //
  }, 1000 * 1);                                                                                //
});                                                                                            // 5
                                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.coffee.js":["fs",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// server/methods.coffee.js                                                                    //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var cl, fs;                                                                                    // 1
                                                                                               //
cl = console.log;                                                                              // 1
                                                                                               //
fs = require('fs');                                                                            // 2
                                                                                               //
HTTP.methods({                                                                                 // 3
  'removeFiles': function(data) {                                                              //
    var err, error;                                                                            // 7
    try {                                                                                      // 7
      data.DEL_FILE_LIST.forEach(function(path) {                                              //
        var err, error, filename, tmp;                                                         // 11
        filename = (tmp = path.split('/'))[tmp.length - 1];                                    //
        if (data.DEL_OPTION === '삭제') {                                                        //
          return fs.unlinkSync(path);                                                          //
        } else if (data.DEL_OPTION === '사이즈0') {                                               //
          return fs.openSync(path, 'w');                                                       //
        } else if (data.DEL_OPTION === '백업') {                                                 //
          try {                                                                                // 17
            return fs.access("" + data.BACKUP_PATH, fs.F_OK, function(err) {                   //
              var errno, error;                                                                // 19
              if (((errno = err != null ? err.errno : void 0) != null) && errno === -2) {      //
                fs.mkdirSync("" + data.BACKUP_PATH);                                           //
              }                                                                                //
              try {                                                                            // 21
                return fs.rename("" + path, data.BACKUP_PATH + "/" + filename, function(err) {
                  return cl(err);                                                              //
                });                                                                            //
              } catch (error) {                                                                //
                err = error;                                                                   //
                return cl(err);                                                                //
              }                                                                                //
            });                                                                                //
          } catch (error) {                                                                    //
            err = error;                                                                       //
            return cl(err);                                                                    //
          }                                                                                    //
        }                                                                                      //
      });                                                                                      //
    } catch (error) {                                                                          //
      err = error;                                                                             //
      cl(err.message);                                                                         //
      return err.message;                                                                      // 32
    }                                                                                          //
    return 'success';                                                                          // 33
  }                                                                                            //
});                                                                                            //
                                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".coffee"]});
require("./lib/mSettings.coffee.js");
require("./server/initServer.coffee.js");
require("./server/methods.coffee.js");
//# sourceMappingURL=app.js.map
